<!doctype html>
<html lang="fr">
<head>
	<meta charset="utf-8">
	<title><?php echo $titre ?></title>
	<link rel="stylesheet" href="./CSS/style.css">
	<script src="./JS/script.js"></script>
</head>
