<footer>
        <div class="flex">
            <div class="centre">Contact</div>
        </div>
        <div class="colonne flex">
            <div class="centre"><?php echo texte("Adresse Postal");?></div>
            <div class="centre"><?php echo texte("Adresse Mail");?></div>
            <div class="centre"><?php echo texte("N° Telephone");?></div>
            <div class="centre"><?php echo texte("N° SIRET");?></div>
        </div>
        <div class="colonne flex">
            <div class="centre"><?php echo texte("Reseaux");?></div>
        </div>
        <div class="logo">
            <a href="index.php?page=default">
                <img src="./IMG/logoPharmacie.jpg" alt="logo Pharmacie">
            </a>
        </div>
    </footer>
</body>

</html>