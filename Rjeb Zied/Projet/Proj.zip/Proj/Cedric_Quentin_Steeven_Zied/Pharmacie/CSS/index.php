<?php // fichier de protection des dossiers. ?>
<h1>ERROR 404 NOT FOUND<h1>